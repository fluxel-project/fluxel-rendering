
fn deform_position(position: vec3<f32>, parameters: vec4<f32>) -> vec3<f32> {
    return vec3<f32>(
        position.x + parameters.x * position.y * position.y + parameters.y,
        position.y,
        position.z + parameters.z * position.x + parameters.w,
    );
}
