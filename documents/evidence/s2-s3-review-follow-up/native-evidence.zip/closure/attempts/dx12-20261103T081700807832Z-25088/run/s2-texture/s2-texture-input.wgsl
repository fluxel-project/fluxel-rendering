
struct Tint { value: vec4<f32>, };
@group(0) @binding(0) var<uniform> s2_tint: Tint;
@group(0) @binding(1) var s2_texture: texture_2d<f32>;
struct VertexOut { @builtin(position) position: vec4<f32>, };
@vertex fn vs_main(@builtin(vertex_index) index: u32) -> VertexOut {
    var positions = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
    var output: VertexOut;
    output.position = vec4<f32>(positions[index], 0.0, 1.0);
    return output;
}
@fragment fn fs_main() -> @location(0) vec4<f32> {
    return textureLoad(s2_texture, vec2<i32>(0, 0), 0) * s2_tint.value;
}
